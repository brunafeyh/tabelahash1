#include <stdio.h>
#include <string.h>
#define TAM 1000 // tamanho da tabela

typedef int TipoChave;
typedef struct {
  int matricula;
  char nome[50];
} TipoRegistro;

typedef struct {
  TipoChave k; // chave
  TipoRegistro r; // registro armazenado
  int ocupado; // indica se o slot está ocupado
} slot;

typedef slot TabelaHash[TAM];

int hash(int k) {
  return k % TAM;
}
void inicializaTabelaHash(TabelaHash T) {
  // percorre a tabela e marca todos os slots como não ocupados
  for (int i = 0; i < TAM; i++) {
    T[i].ocupado = 0;
  }
}

void inserir(TabelaHash T, TipoChave k, TipoRegistro r) {
  // calcula a posição inicial da chave na tabela usando a função hash
  int pos = hash(k);
  // verifica se a posição está ocupada
  if (T[pos].ocupado) {
    // inicia a sondagem linear para encontrar uma posição livre
    int i = 1;
    while (i < TAM) {
      // calcula a nova posição usando o deslocamento i
      int nova_pos = (pos + i) % TAM;
      // verifica se a nova posição está livre
      if (!T[nova_pos].ocupado) {
        // insere a chave e o registro na nova posição
        T[nova_pos].k = k;
        T[nova_pos].r = r;
        T[nova_pos].ocupado = 1;
        // sai do laço
        break;
      }
      // incrementa o deslocamento
      i++;
    }
    // verifica se a sondagem linear encontrou uma posição livre
    if (i == TAM) {
      // imprime uma mensagem de erro e ignora a inserção
      printf("Tabela cheia\n");
    }
  } else {
    // insere a chave e o registro na posição inicial
    T[pos].k = k;
    T[pos].r = r;
    T[pos].ocupado = 1;
  }
}

// retorna a posição do registro de chave k na tabela hash T
// ou -1 caso a chave não esteja presente.
int buscar(TabelaHash T, TipoChave k) {
  // calcula a posição inicial da chave na tabela usando a função hash
  int pos = hash(k);
  // verifica se a posição está ocupada e se a chave é igual à buscada
  if (T[pos].ocupado && T[pos].k == k) {
    // retorna a posição inicial
    return pos;
  } else {
    // inicia a sondagem linear para encontrar a chave
    int i = 1;
    while (i < TAM) {
      // calcula a nova posição usando o deslocamento i
      int nova_pos = (pos + i) % TAM;
      // verifica se a nova posição está ocupada e se a chave é igual à buscada
      if (T[nova_pos].ocupado && T[nova_pos].k == k) {
        // retorna a nova posição
        return nova_pos;
      }
      // incrementa o deslocamento
      i++;
    }
    // verifica se a sondagem linear encontrou a chave
    if (i == TAM) {
      // retorna -1
      return -1;
    }
  }
}

void remover(TabelaHash T, TipoChave k) {
  // busca a posição do registro de chave k na tabela
  int pos = buscar(T, k);
  // verifica se a posição é válida
  if (pos != -1) {
    // marca a posição como não ocupada
    T[pos].ocupado = 0;
  } else {
    // imprime uma mensagem de erro
    printf("Chave não encontrada\n");
  }
}


int main() {
  // cria uma tabela hash vazia
  TabelaHash T;
  inicializaTabelaHash(T);

  // cria alguns registros para testar as funções
  TipoRegistro r1, r2, r3, r4;
  r1.matricula = 123;
  strcpy(r1.nome, "Alice");
  r2.matricula = 456;
  strcpy(r2.nome, "Bob");
  r3.matricula = 789;
  strcpy(r3.nome, "Charlie");
  r4.matricula = 123;
  strcpy(r4.nome, "David");

  // insere os registros na tabela hash
  inserir(T, r1.matricula, r1);
  inserir(T, r2.matricula, r2);
  inserir(T, r3.matricula, r3);
  inserir(T, r4.matricula, r4); // deve imprimir "Posição ocupada"

  // busca os registros na tabela hash
  int pos1 = buscar(T, r1.matricula);
  int pos2 = buscar(T, r2.matricula);
  int pos3 = buscar(T, r3.matricula);
  int pos4 = buscar(T, r4.matricula); // deve retornar -1

  // imprime os resultados das buscas
  printf("Posição de %s: %d\n", r1.nome, pos1);
  printf("Posição de %s: %d\n", r2.nome, pos2);
  printf("Posição de %s: %d\n", r3.nome, pos3);
  printf("Posição de %s: %d\n", r4.nome, pos4);

  // remove os registros da tabela hash
  remover(T, r1.matricula);
  remover(T, r2.matricula);
  remover(T, r3.matricula);
  remover(T, r4.matricula); // deve imprimir "Chave não encontrada"

  return 0;
}