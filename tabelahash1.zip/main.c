#include <stdio.h>
#include <string.h>
#define TAM 1000 // tamanho da tabela

typedef int TipoChave;
typedef struct {
  int matricula;
  char nome[50];
} TipoRegistro;

typedef struct {
  TipoChave k; // chave
  TipoRegistro r; // registro armazenado
  int ocupado; // indica se o slot está ocupado
} slot;

typedef slot TabelaHash[TAM];

void inicializaTabelaHash(TabelaHash T) {
  // percorre a tabela e marca todos os slots como não ocupados
  for (int i = 0; i < TAM; i++) {
    T[i].ocupado = 0;
  }
}

int hash(int k) {
  return k % TAM;
}

void inserir(TabelaHash T, TipoChave k, TipoRegistro r) {
  // calcula a posição da chave na tabela usando a função hash
  int pos = hash(k);
  // verifica se a posição está ocupada
  if (T[pos].ocupado) {
    // imprime uma mensagem de erro e ignora a inserção
    printf("Posição ocupada\n");
  } else {
    // insere a chave e o registro na posição
    T[pos].k = k;
    T[pos].r = r;
    T[pos].ocupado = 1;
  }
}

// retorna a posição do registro de chave k na tabela hash T
// ou -1 caso a chave não esteja presente.
int buscar(TabelaHash T, TipoChave k) {
  // calcula a posição da chave na tabela usando a função hash
  int pos = hash(k);
  // verifica se a posição está ocupada e se a chave é igual à buscada
  if (T[pos].ocupado && T[pos].k == k) {
    // retorna a posição
    return pos;
  } else {
    // retorna -1
    return -1;
  }
}

void remover(TabelaHash T, TipoChave k) {
  // busca a posição do registro de chave k na tabela
  int pos = buscar(T, k);
  // verifica se a posição é válida
  if (pos != -1) {
    // marca a posição como não ocupada
    T[pos].ocupado = 0;
  } else {
    // imprime uma mensagem de erro
    printf("Chave não encontrada\n");
  }
}


int main() {
  // cria uma tabela hash vazia
  TabelaHash T;
  inicializaTabelaHash(T);

  // cria alguns registros para testar as funções
  TipoRegistro r1, r2, r3, r4;
  r1.matricula = 123;
  strcpy(r1.nome, "Alice");
  r2.matricula = 456;
  strcpy(r2.nome, "Bob");
  r3.matricula = 789;
  strcpy(r3.nome, "Charlie");
  r4.matricula = 123;
  strcpy(r4.nome, "David");

  // insere os registros na tabela hash
  inserir(T, r1.matricula, r1);
  inserir(T, r2.matricula, r2);
  inserir(T, r3.matricula, r3);
  inserir(T, r4.matricula, r4); // deve imprimir "Posição ocupada"

  // busca os registros na tabela hash
  int pos1 = buscar(T, r1.matricula);
  int pos2 = buscar(T, r2.matricula);
  int pos3 = buscar(T, r3.matricula);
  int pos4 = buscar(T, r4.matricula); // deve retornar -1

  // imprime os resultados das buscas
  printf("Posição de %s: %d\n", r1.nome, pos1);
  printf("Posição de %s: %d\n", r2.nome, pos2);
  printf("Posição de %s: %d\n", r3.nome, pos3);
  printf("Posição de %s: %d\n", r4.nome, pos4);

  // remove os registros da tabela hash
  remover(T, r1.matricula);
  remover(T, r2.matricula);
  remover(T, r3.matricula);
  remover(T, r4.matricula); // deve imprimir "Chave não encontrada"

  return 0;
}
